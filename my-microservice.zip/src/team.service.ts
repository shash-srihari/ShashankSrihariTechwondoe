import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Team, TeamDocument } from './team.model';
import { CreateTeamDto } from './dto/create-team.dto';

@Injectable()
export class TeamService {
  constructor(@InjectModel(Team.name) private readonly teamModel: Model<TeamDocument>) {}

  async createTeam(companyId: string, createTeamDto: CreateTeamDto): Promise<Team> {
    const team = new this.teamModel({
      teamLeadName: createTeamDto.teamLeadName,
      company: companyId,
    });
    return team.save();
  }

  async getTeamById(teamId: string): Promise<Team | null> {
    return this.teamModel.findById(teamId);
  }
  
}
