import {
  Body,
  Controller,
  Get,
  Param,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { AppService } from './app.service';
import { JwtAuthGuard } from './auth/jwt-auth.guard';
import { CreateCompanyDto } from './dto/create-company.dto';
//import { CreateTeamDto } from './dto/create-team.dto';
import { CompanyService } from './company.service';
import { TeamService } from './team.service';
import { CompanyController } from './company.controller';
import { Company, CompanyDocument } from './company.model';

@Controller()
export class AppController {
  constructor(
    private readonly appService: AppService,
    private readonly companyService: CompanyService,
  ) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }
  @Post('createCompany')
  @UseGuards(JwtAuthGuard)
  async createCompany(
    @Body() createCompanyDto: CreateCompanyDto,
  ): Promise<CompanyDocument> {
    const companyService = new CompanyService(CompanyDocument, TeamDocument);
    const companyController = new CompanyController();
    return await companyController.createCompany(createCompanyDto);
  }

  @Get('fetchCompany/:companyId')
  @UseGuards(JwtAuthGuard)
  fetchCompany(@Param('companyId') companyId: string) {
    return this.companyService.fetchCompany(companyId);
  }

  @Get('getAllTeams')
  @UseGuards(JwtAuthGuard)
  getAllTeams() {
    return this.companyService.getAllTeams();
  }

  @Post('createTeam')
  @UseGuards(JwtAuthGuard)
  createTeam(@Body() createTeamDto: CreateTeamDto) {
    return this.companyService.createTeam(createTeamDto);
  }

  @Get('fetchCompany')
  @UseGuards(JwtAuthGuard)
  fetchCompanyByName(@Query('name') name: string) {
    return this.companyService.fetchCompanyByName(name);
  }
}
