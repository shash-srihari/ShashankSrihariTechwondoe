import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type CompanyDocument = Company & Document;

@Schema()
export class Company {
  @Prop({ required: true })
  name!: string;

  @Prop({ required: true })
  CEO!: string;

  @Prop({ required: true })
  address!: string;

  @Prop({ required: true })
  inceptionDate!: Date;
}

export const CompanySchema = SchemaFactory.createForClass(Company);
