import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './auth/auth.module';
import { CompanyController } from './company.controller';
import { TeamController } from './team.controller';
import { CompanyService } from './company.service';
import { TeamService } from './team.service';
import { TeamModule } from './team.module';

@Module({
  imports: [
    AuthModule,
    JwtModule.register({
      // Configure JWT options, such as secret key and token expiration
      secret: 'ShashankSrihariTechwondoe', // Replace with your actual secret key
      signOptions: { expiresIn: '1h' }, // Example token expiration time (1 hour)
    }),
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
