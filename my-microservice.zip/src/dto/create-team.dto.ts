export class CreateTeamDto {
    teamLeadName!: string;
  }