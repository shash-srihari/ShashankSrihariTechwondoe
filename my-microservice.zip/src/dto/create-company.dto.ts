export class CreateCompanyDto {
    name!: string;
    ceo!: string;
    address!: string;
    inceptionDate!: Date;
  }
  