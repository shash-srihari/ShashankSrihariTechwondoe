import { Controller, Post, Body, Param, Get } from '@nestjs/common';
import { TeamService } from './team.service';
import { CreateTeamDto } from './dto/create-team.dto';

@Controller('teams')
export class TeamController {
  constructor(private readonly teamService: TeamService) {}

  @Post(':companyId')
  createTeam(@Param('companyId') companyId: string, @Body() createTeamDto: CreateTeamDto) {
    return this.teamService.createTeam(companyId, createTeamDto);
  }

  @Get(':teamId')
  getTeamById(@Param('teamId') teamId: string) {
    return this.teamService.getTeamById(teamId);
  }
}
