import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
import { Company } from './company.model';

export type TeamDocument = Team & Document;

@Schema()
export class Team {
  @Prop({ type: Types.ObjectId, ref: 'Company', required: true })
  companyId!: Types.ObjectId;

  @Prop({ required: true })
  teamLeadName!: string;
}

export const TeamSchema = SchemaFactory.createForClass(Team);
