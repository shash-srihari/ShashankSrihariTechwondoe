import { Injectable, UnauthorizedException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Company, CompanyDocument } from './company.model';
import { Team, TeamDocument } from './team.model';
import { CreateCompanyDto } from './dto/create-company.dto';
import { CreateTeamDto } from './dto/create-team.dto';

@Injectable()
export class CompanyService {
  constructor(
    @InjectModel(Company.name) private readonly companyModel: Model<CompanyDocument>,
    @InjectModel(Team.name) private readonly teamModel: Model<TeamDocument>,
  ) {}

  async createCompany(createCompanyDto: CreateCompanyDto): Promise<CompanyDocument> {
    const createdCompany = new this.companyModel(createCompanyDto);
    return createdCompany.save();
  }

  async createTeam(createTeamDto: CreateTeamDto): Promise<TeamDocument> {
    const createdTeam = new this.teamModel(createTeamDto);
    return createdTeam.save();
  }

  async fetchCompany(companyId: string): Promise<CompanyDocument | null> {
    return this.companyModel.findById(companyId).exec();
  }

  async fetchCompanyByName(name: string): Promise<CompanyDocument[]> {
    return this.companyModel.find({ name }).exec();
  }

  async getAllTeams(): Promise<CompanyDocument[]> {
    return this.companyModel.find().populate('teams').exec();
  }
}
