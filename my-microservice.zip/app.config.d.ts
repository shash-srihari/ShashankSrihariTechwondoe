declare const _default: () => {
    jwtSecret: string | undefined;
};
export default _default;
